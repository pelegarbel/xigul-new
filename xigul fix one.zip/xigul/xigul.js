var Totzaot = [["","",""],["","",""],["","",""]];
var Tor = 'X';


var timeouter = null;

//this function check if the player pass his time to play and if it is then he get massage that he losses 
function restartTimer()
{
    if(timeouter) clearTimeout(timeouter);    
    timeouter = setTimeout(() => {
        IpusTable();
        alert("you loose");        
        restartTimer();               
    }, 30000);
}

restartTimer();


function X(x,y)
{
    if(Totzaot[x][y]!="")
        return;
    restartTimer();

    document.getElementById('rc' + x + y).innerHTML = Tor;
    Totzaot[x][y] = Tor;
    Tor = Tor == "X" ? "O" : "X"

    CheckWin()
    
}
// This function checks who won by checking rows and columns and in addition diagonal by indexes
function CheckWin()
{
    if(
        Totzaot[0][0] == 'X' && Totzaot[0][1] == 'X' && Totzaot[0][2] == 'X' ||
        Totzaot[1][0] == 'X' && Totzaot[1][1] == 'X' && Totzaot[1][2] == 'X' ||
        Totzaot[2][0] == 'X' && Totzaot[2][1] == 'X' && Totzaot[2][2] == 'X' ||
        Totzaot[0][0] == 'X' && Totzaot[1][0] == 'X' && Totzaot[2][0] == 'X' ||
        Totzaot[0][1] == 'X' && Totzaot[1][1] == 'X' && Totzaot[2][1] == 'X' ||
        Totzaot[0][2] == 'X' && Totzaot[1][2] == 'X' && Totzaot[2][2] == 'X' ||
        Totzaot[0][0] == 'X' && Totzaot[1][1] == 'X' && Totzaot[2][2] == 'X' ||
        Totzaot[0][2] == 'X' && Totzaot[1][1] == 'X' && Totzaot[2][0] == 'X' 
    )
        {
            alert("X wins")
            Tor = 'X';
            Totzaot = [["","",""],["","",""],["","",""]];
            IpusTable()
        }

    if(
        Totzaot[0][0] == 'O' && Totzaot[0][1] == 'O' && Totzaot[0][2] == 'O' ||
        Totzaot[1][0] == 'O' && Totzaot[1][1] == 'O' && Totzaot[1][2] == 'O' ||
        Totzaot[2][0] == 'O' && Totzaot[2][1] == 'O' && Totzaot[2][2] == 'O' ||
        Totzaot[0][0] == 'O' && Totzaot[1][0] == 'O' && Totzaot[2][0] == 'O' ||
        Totzaot[0][1] == 'O' && Totzaot[1][1] == 'O' && Totzaot[2][1] == 'O' ||
        Totzaot[0][2] == 'O' && Totzaot[1][2] == 'O' && Totzaot[2][2] == 'O' ||
        Totzaot[0][0] == 'O' && Totzaot[1][1] == 'O' && Totzaot[2][2] == 'O' ||
        Totzaot[0][2] == 'O' && Totzaot[1][1] == 'O' && Totzaot[2][0] == 'O' 
    )
    {
            alert("O wins")
            Tor = 'X';
            Totzaot = [["","",""],["","",""],["","",""]];
            IpusTable()
        }

}
// this function is reset the table of the game 
function IpusTable()
{

    for(var x = 0 ; x < 3 ; x++)
        for(var y = 0 ; y < 3 ; y++)
            document.getElementById('rc' + x + y).innerHTML = "";
}